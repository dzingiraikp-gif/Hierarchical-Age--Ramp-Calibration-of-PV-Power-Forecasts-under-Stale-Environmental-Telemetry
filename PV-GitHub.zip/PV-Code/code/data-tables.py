"""Construct manuscript tables directly from the source records and saved results."""
import pathlib,sys,json
import pandas as pd,numpy as np
P=pathlib.Path(__file__).resolve().parents[1];T=P/'tables';R=P/'results';T.mkdir(exist_ok=True)
rawpath=P.parent/'work'/'raw.pkl'
if rawpath.exists():d=pd.read_pickle(rawpath)
else:
 root=pathlib.Path(sys.argv[1]);d=pd.concat([pd.read_csv(f) for f in root.rglob('*.csv')]);d.measured_on=pd.to_datetime(d.measured_on);d=d.set_index('measured_on').sort_index()
ext=pd.concat([pd.read_csv(f) for f in (P/'data/future').glob('*.csv')]);ext.measured_on=pd.to_datetime(ext.measured_on);ext=ext.set_index('measured_on').sort_index()
def tab(name,heads,rows,fmt):
 s='\\begin{tabular}{'+fmt+'}\n\\toprule\n'+' & '.join(heads)+r' \\'+'\n\\midrule\n'+'\n'.join(' & '.join(map(str,r))+r' \\' for r in rows)+'\n\\bottomrule\n\\end{tabular}\n';(T/(name+'.tex')).write_text(s)
def export(name,df):df.to_csv(R/(name+'.csv'),index=False)
labels={'ac_current__427':'AC current','ac_power__423':'AC power','ac_voltage__426':'AC voltage','ambient_temp__428':'Ambient temperature','das_battery_voltage__434':'DAQ battery voltage','das_temp__433':'DAQ temperature','dc_pos_current__425':'DC current','dc_pos_voltage__424':'DC voltage','dc_power__422':'DC power','inverter_temp__432':'Inverter temperature','module_temp_1__429':'Module temperature 1','module_temp_2__430':'Module temperature 2','module_temp_3__431':'Module temperature 3','poa_irradiance__421':'POA irradiance'}
summary=[]
for c,label in labels.items():
 a=d[c];summary.append(dict(variable=label,n=int(a.notna().sum()),missing=int(a.isna().sum()),mean=a.mean(),std=a.std(),minimum=a.min(),median=a.median(),maximum=a.max()))
f=pd.DataFrame(summary);export('measurement-statistics',f)
tab('measurement-statistics',['Measurement','Mean','SD','Minimum','Median','Maximum','Missing'],[[r.variable]+[f'{(0 if abs(getattr(r,c))<.005 else getattr(r,c)):.2f}' for c in ['mean','std','minimum','median','maximum']]+[r.missing] for r in f.itertuples()],'lrrrrrr')
months=[]
for date,group in d.groupby(d.index.to_period('M')):
 expected=date.days_in_month*1440;months.append(dict(month=str(date),records=len(group),missing_records=expected-len(group),empty_cells=int(group.isna().sum().sum()),mean_ac=group.ac_power__423.mean(),max_ac=group.ac_power__423.max(),mean_poa=group.poa_irradiance__421.mean()))
f=pd.DataFrame(months);export('monthly-inventory',f);tab('monthly-inventory',['Month','Records','Absent minutes','Empty cells','Mean AC','Max. AC'],[[r.month,f'{r.records:,}',f'{r.missing_records:,}',r.empty_cells,f'{r.mean_ac:.2f}',f'{r.max_ac:.2f}'] for r in f.itertuples()],'lrrrrr')
samples=[]
for source,df,day in [('A',d,'2021-01-01'),('P',ext,'2022-01-01')]:
 for hour in [9,12,15]:
  date=pd.Timestamp(day)+pd.Timedelta(hours=hour);r=df.loc[date];samples.append({'origin':source,'timestamp':date.strftime('%Y-%m-%d %H:%M'),'ac':r.ac_power__423,'dc':r.dc_power__422,'poa':r.poa_irradiance__421,'ambient':r.ambient_temp__428,'module':r[['module_temp_1__429','module_temp_2__430','module_temp_3__431']].mean()})
f=pd.DataFrame(samples);export('sample-observations',f);tab('sample-observations',['Copy','Timestamp','AC','DC','POA','Ambient','Module'],[[r.origin,r.timestamp]+[f'{getattr(r,c):.2f}' for c in ['ac','dc','poa','ambient','module']] for r in f.itertuples()],'llrrrrr')
fields=[]
for c,label in labels.items():
 selected=c in ['ac_power__423','dc_power__422','poa_irradiance__421','ambient_temp__428','inverter_temp__432'] or c.startswith('module_temp_');role='Forecast target and history' if c=='ac_power__423' else 'Current electrical history' if c=='dc_power__422' else 'Mean and spread derived' if c.startswith('module_temp_') else 'Age-controlled input' if selected else 'Recorded; not a predictor'
 fields.append([label,c.rsplit('__',1)[-1],role])
tab('measurement-dictionary',['Measurement','Metric ID','Role in the experiment'],fields,'llp{68mm}')
m=pd.read_csv(R/'metrics.csv');pb=pd.read_csv(R/'point-baselines.csv')
rows=[]
for name,label in [('Persistence','Persistence'),('Ridge','Ridge'),('Boosting raw','Quantile boosting'),('TCN raw','TCN'),('GRU-17','GRU'),('MLP-17','MLP')]:
 df=pb if name in ['Persistence','Ridge'] else m;v=df[(df.model==name)&(df.subset=='All')].groupby('horizon').RMSE.mean();rows.append([label]+[f'{v[h]:.2f}' for h in [5,15,30,60]])
tab('rmse-comparison',['Model','5 min','15 min','30 min','60 min'],rows,'lrrrr')
rows=[]
for name,label in [('Boosting raw','Raw'),('Boosting Rolling','Rolling global'),('Boosting Separate','Separate groups'),('Boosting Pooled','Hierarchical')]:
 for sub in ['Stable','Ramp','Daylight']:
  v=m[(m.model==name)&(m.subset==sub)];rows.append([label,sub,int(v.n.iloc[0]) if sub!='Daylight' else '--',f'{v.coverage.mean()*100:.2f}',f'{v.width.mean():.2f}',f'{v.IS90.mean():.2f}'])
tab('conditional-results',['Method','Subset','Origins','Coverage (\\%)','Width','IS90'],rows,'llrrrr')
rows=[]
for a in [0,15,60]:
 for h in [5,15,30,60]:
  r=m.query('model=="Boosting Pooled" and age==@a and horizon==@h and subset=="All"').iloc[0];rows.append([a,h,f'{r.MAE:.2f}',f'{r.RMSE:.2f}',f'{r.pinball:.2f}',f'{r.coverage*100:.2f}'])
tab('complete-errors',['Age (min)','Horizon (min)','MAE','RMSE','Pinball','Coverage (\\%)'],rows,'rrrrrr')
boot=pd.read_csv(R/'bootstrap.csv');tab('bootstrap-values',['Age (min)','Horizon (min)','Mean difference','95\\% lower','95\\% upper'],[[int(r.age),int(r.horizon),f'{r.difference:.2f}',f'{r.low:.2f}',f'{r.high:.2f}'] for r in boot.itertuples()],'rrrrr')
rows=[]
for nm,label in [('Boosting AgeOnly','Age only'),('Boosting RampOnly','Ramp only'),('Boosting Separate','Separate age--ramp'),('Boosting Pooled','Hierarchical age--ramp')]:
 v=m[(m.model==nm)&(m.subset=='All')];rows.append([label,f'{v.coverage.mean()*100:.2f}',f'{v.width.mean():.2f}',f'{v.IS90.mean():.2f}'])
tab('conditioning',['Structure','Coverage (\\%)','Width','IS90'],rows,'lrrr')
print('Created source-data, descriptive-statistics and detailed-results tables.')
