"""Figures use vertically separated panels and dedicated legend rows."""
import pathlib,json,sys
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.colors import TwoSlopeNorm
P=pathlib.Path(__file__).resolve().parents[1];R=P/'results';F=P/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.spines.top':False,'axes.spines.right':False,'axes.labelsize':10.5,'axes.titlesize':10.5,'legend.fontsize':9,'figure.dpi':120,'pdf.fonttype':42,'ps.fonttype':42,'axes.titlepad':10})
C=['#176B87','#C96C24','#497B44','#88548C','#AC3C43','#606971'];marks=['o','s','^','D','P','X']
def panels(n,legend=True,height=2.55):
 fig=plt.figure(figsize=(6.65,n*height+(.65 if legend else .25)),layout='constrained')
 gs=fig.add_gridspec(n+int(legend),1,height_ratios=([.48] if legend else [])+[height]*n)
 lax=fig.add_subplot(gs[0]) if legend else None
 if lax is not None:lax.axis('off')
 axs=[fig.add_subplot(gs[j+int(legend)]) for j in range(n)]
 return fig,axs,lax
def legend(lax,ax,ncol=3,title=None):
 h,l=ax.get_legend_handles_labels();lax.legend(h,l,loc='center',ncol=ncol,frameon=False,columnspacing=1.5,handlelength=2,title=title)
def save(name):
 fig=plt.gcf();fig.canvas.draw()
 # Every nonempty legend is placed in a separate axes row.
 fig.savefig(F/(name+'.pdf'),metadata={'Author':'','Creator':''})
 fig.savefig(F/(name+'.png'),dpi=300,metadata={'Author':''});plt.close(fig)
z=np.load(R/'prepared.npz');t=pd.to_datetime(z['time']);test=z['split']==3;y=z['Y']*1300;g=z['group'];q=np.load(R/'intervals.npz');m=pd.read_csv(R/'metrics.csv');pb=pd.read_csv(R/'point-baselines.csv');H=[5,15,30,60];A=[0,15,60]
rawpath=P.parent/'work'/'raw.pkl'
if rawpath.exists():raw=pd.read_pickle(rawpath)
elif '--data' in sys.argv:
 root=pathlib.Path(sys.argv[sys.argv.index('--data')+1]);raw=pd.concat([pd.read_csv(f) for f in root.rglob('*.csv')]);raw.measured_on=pd.to_datetime(raw.measured_on);raw=raw.set_index('measured_on').sort_index()
else:raw=None
if raw is not None:
 mat=raw.ac_power__423.groupby([raw.index.dayofyear,raw.index.hour*60+raw.index.minute]).mean().unstack().reindex(index=range(1,366),columns=range(1440))
 fig,axs,_=panels(1,False,3.2);ax=axs[0];im=ax.imshow(mat,aspect='auto',origin='lower',extent=[0,24,1,365],cmap='viridis',vmin=0,vmax=1300);ax.set(xlabel='Recorded clock hour',ylabel='Day of 2021',xticks=[0,6,12,18,24]);fig.colorbar(im,ax=ax,orientation='horizontal',pad=.12,fraction=.07,label='AC power (source units)');save('annual-power')
 tr=raw[raw.index<pd.Timestamp('2021-07-01')];tr=tr[(tr.poa_irradiance__421>20)&tr.module_temp_1__429.notna()].iloc[::5]
 fig,axs,_=panels(2,False,2.7);sc=axs[0].scatter(tr.poa_irradiance__421,tr.ac_power__423,c=tr.module_temp_1__429,s=4,cmap='plasma',rasterized=True,alpha=.6);axs[0].set(xlabel='POA irradiance (source units)',ylabel='AC power (source units)',title='(a) Training operating envelope');fig.colorbar(sc,ax=axs[0],pad=.025,label='Module temperature (source units)')
 im=axs[1].hexbin(tr.dc_power__422,tr.ac_power__423,gridsize=45,cmap='viridis',mincnt=1);axs[1].set(xlabel='DC power (source units)',ylabel='AC power (source units)',title='(b) Electrical conversion relationship');fig.colorbar(im,ax=axs[1],pad=.025,label='Training observations');save('operating-envelope')
fig,axs,lax=panels(2)
for j,(name,label,c) in enumerate([('Persistence','Persistence',C[5]),('Ridge','Ridge',C[4]),('Boosting raw','Quantile boosting',C[0]),('TCN raw','TCN',C[1]),('GRU-17','GRU',C[2]),('MLP-17','MLP',C[3])]):
 df=pb if name in ['Persistence','Ridge'] else m
 for age,ax in zip([0,60],axs):
  d=df[(df.model==name)&(df.age==age)&(df.subset=='All')].sort_values('horizon');ax.plot(d.horizon,d.MAE,marker=marks[j],lw=1.5,ms=4,c=c,label=label)
for ax,a in zip(axs,[0,60]):ax.set(xlabel='Forecast horizon (min)',ylabel='MAE (source units)',title=f'Environmental reading age: {a} min',xticks=H);ax.grid(alpha=.15)
legend(lax,axs[0]);save('forecast-errors')
fig,axs,lax=panels(3,height=2.25)
for ax,age in zip(axs,A):
 for j,(nm,label,c,ls) in enumerate([('Boosting raw','Raw',C[5],':'),('Boosting Rolling','Rolling global',C[1],'--'),('Boosting Separate','Separate groups',C[2],'-.'),('Boosting Pooled','Hierarchical',C[0],'-')]):
  d=m[(m.model==nm)&(m.age==age)&(m.subset=='Ramp')].sort_values('horizon');ax.plot(d.horizon,100*d.coverage,marker=marks[j],ls=ls,label=label,c=c,ms=4)
 ax.axhline(90,c='black',lw=.8);ax.set(xlabel='Horizon (min)',ylabel='Ramp coverage (%)',title=f'Environmental reading age: {age} min',xticks=H);ax.grid(alpha=.15)
legend(lax,axs[0],2);save('ramp-coverage')
fig,axs,lax=panels(2)
for ax,age in zip(axs,[0,60]):
 for j,(nm,label) in enumerate([('Boosting raw','Raw'),('Boosting Fixed','Fixed'),('Boosting Rolling','Rolling'),('Boosting ACI','Daily ACI'),('Boosting Separate','Separate groups'),('Boosting Pooled','Hierarchical')]):
  r=m.query('model==@nm and age==@age and horizon==30 and subset=="All"').iloc[0];ax.scatter(r.width,r.coverage*100,s=65,c=C[j],marker=marks[j],label=label,edgecolor='white',linewidth=.5)
 ax.axhline(90,c='black',lw=.7);ax.set(xlabel='Mean interval width (source units)',ylabel='Coverage (%)',title=f'30-min horizon; environmental age {age} min');ax.margins(.15)
legend(lax,axs[0]);save('coverage-width')
fig,axs,_=panels(2,False,2.9)
for ax,sub in zip(axs,['All','Ramp']):
 d=m[(m.subset==sub)&m.model.isin(['Boosting Pooled','Boosting Rolling'])];tab=d.pivot(index='age',columns=['model','horizon'],values='IS90');diff=tab['Boosting Rolling']-tab['Boosting Pooled'];bound=max(abs(diff.values).max(),1);norm=TwoSlopeNorm(vmin=-bound,vcenter=0,vmax=bound);im=ax.imshow(diff,cmap='RdBu',aspect='auto',norm=norm);ax.set(xticks=range(4),xticklabels=H,yticks=range(3),yticklabels=A,xlabel='Horizon (min)',ylabel='Environmental age (min)',title=f'{sub} forecast origins')
 for i in range(3):
  for j in range(4):ax.text(j,i,f'{diff.values[i,j]:.1f}',ha='center',va='center',fontsize=11,color='white' if abs(diff.values[i,j])/bound>.65 else 'black')
 fig.colorbar(im,ax=ax,pad=.025,label='IS90 reduction (source units)')
save('score-improvement')
fig,axs,lax=panels(2)
for name,label,c in [('Boosting raw','Raw',C[5]),('Boosting Rolling','Rolling',C[1]),('Boosting Pooled','Hierarchical',C[0])]:
 a=q[name][:,0,2];df=pd.DataFrame({'day':t[test].normalize(),'coverage':((y[test,2]>=a[test,0])&(y[test,2]<=a[test,2])).astype(float),'width':a[test,2]-a[test,0]});daily=df.groupby('day').mean();axs[0].plot(daily.index,daily.coverage.rolling(7,min_periods=7).mean()*100,label=label,c=c);axs[1].plot(daily.index,daily.width.rolling(7,min_periods=7).mean(),c=c)
axs[0].axhline(90,c='black',lw=.7);axs[0].set(ylabel='Seven-day coverage (%)',title='30-min horizon; fresh environmental readings');axs[1].set(ylabel='Mean width (source units)',title='Seven-day interval sharpness')
for ax in axs:ax.xaxis.set_major_locator(mdates.MonthLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'));ax.set_xlabel('Forecast day')
legend(lax,axs[0]);save('sequential-reliability')
ramp=z['ramp'];ds=pd.Series(ramp[test],index=t[test]).groupby(t[test].normalize()).mean();chosen=[ds.idxmin(),ds.idxmax()]
fig,axs,lax=panels(2,height=2.65)
for ax,day,label in zip(axs,chosen,['Lowest historical variability','Highest historical variability']):
 ix=test&(t.normalize()==day);a=q['Boosting Pooled'][ix,2,2];ax.fill_between(t[ix],a[:,0],a[:,2],color=C[0],alpha=.2,label='90% interval');ax.plot(t[ix],y[ix,2],color='black',lw=1,label='Observed target');ax.plot(t[ix],a[:,1],color=C[0],lw=1.2,label='Median');ax.set(title=f'{label}: {day.date()}',ylabel='AC power (source units)',xlabel='Forecast issuance time');ax.xaxis.set_major_locator(mdates.HourLocator(byhour=[6,9,12,15,18]));ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M'))
legend(lax,axs[0]);save('forecast-examples')
fig,axs,lax=panels(2)
for j,(h,c) in enumerate(zip(H,C)):
 d=m.query('model=="Boosting Pooled" and horizon==@h and subset=="All"').sort_values('age');axs[0].plot(d.age,d.MAE,marker=marks[j],c=c,label=f'{h} min');axs[1].plot(d.age,d.IS90,marker=marks[j],c=c)
axs[0].set(xlabel='Environmental reading age (min)',ylabel='MAE (source units)',xticks=A);axs[1].set(xlabel='Environmental reading age (min)',ylabel='IS90 (source units)',xticks=A);legend(lax,axs[0],4,title='Forecast horizon');save('sensor-age')
b=pd.read_csv(R/'bootstrap.csv');fig,axs,lax=panels(1,height=2.9);ax=axs[0]
for j,age in enumerate(A):
 d=b[b.age==age];xx=np.arange(4)+(j-1)*.16;ax.errorbar(xx,d.difference,yerr=np.stack([d.difference-d.low,d.high-d.difference]),fmt=marks[j],capsize=4,color=C[j],label=f'Age {age} min')
ax.axhline(0,c='black',lw=.8);ax.set(xticks=range(4),xticklabels=H,xlabel='Horizon (min)',ylabel='Hierarchical minus rolling IS90',title='Seven-day block bootstrap: 95% intervals');legend(lax,ax);save('paired-comparison')
names=['TCN raw','TCN-17-anchor1-age0-augment1','TCN-17-anchor0-age1-augment1','TCN-17-anchor1-age1-augment0'];labels=['TCN reference','Without age channel','Without power anchor','Without stale-input training'];fig,axs,lax=panels(2)
for j,(name,label) in enumerate(zip(names,labels)):
 d=m[(m.model==name)&(m.subset=='All')].groupby('age')[['MAE','IS90']].mean();axs[0].plot(d.index,d.MAE,marker=marks[j],c=C[j],label=label);axs[1].plot(d.index,d.IS90,marker=marks[j],c=C[j])
axs[0].set(xlabel='Environmental reading age (min)',ylabel='MAE (source units)',xticks=A);axs[1].set(xlabel='Environmental reading age (min)',ylabel='Raw interval score',xticks=A);legend(lax,axs[0],2);save('neural-components')
fig,axs,lax=panels(1,height=2.9);ax=axs[0]
for seed,c in zip([17,29,43],C):
 d=m[(m.model==('TCN raw' if seed==17 else f'TCN-{seed}'))&(m.subset=='All')].groupby('horizon').MAE.mean();ax.plot(d.index,d.values,'o-',c=c,label=f'TCN seed {seed}')
ax.set(xlabel='Horizon (min)',ylabel='MAE (source units)',xticks=H);legend(lax,ax);save('training-variation')
if (R/'future-metrics.csv').exists():
 fm=pd.read_csv(R/'future-metrics.csv');fig,axs,lax=panels(2)
 for j,(name,label,c) in enumerate([('raw','Raw',C[5]),('Rolling','Rolling global',C[1]),('Separate','Separate groups',C[2]),('Pooled','Hierarchical',C[0])]):
  d=fm[(fm.model==name)&(fm.subset=='All')].groupby('horizon').mean(numeric_only=True);axs[0].plot(d.index,d.coverage*100,marker=marks[j],c=c,label=label);axs[1].plot(d.index,d.IS90,marker=marks[j],c=c)
 axs[0].axhline(90,c='black',lw=.7);axs[0].set(xlabel='Horizon (min)',ylabel='Coverage (%)',xticks=H);axs[1].set(xlabel='Horizon (min)',ylabel='IS90 (source units)',xticks=H);legend(lax,axs[0],2);save('future-year')
print('Saved all figures with vertical panels and separate legend rows.')
