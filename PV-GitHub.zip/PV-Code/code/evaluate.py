"""Daily prequential interval calibration; no same-day outcome is used."""
import pathlib,json
import numpy as np,pandas as pd
P=pathlib.Path(__file__).resolve().parents[1];R=P/'results';SCALE=1300
z=np.load(R/'prepared.npz');Y=z['Y']*SCALE;split=z['split'];tm=pd.to_datetime(z['time']);days=tm.normalize();group=z['group'];ages=[0,15,60];H=[5,15,30,60]

def intervalscore(y,l,u,alpha=.1):return u-l+2/alpha*np.maximum(l-y,0)+2/alpha*np.maximum(y-u,0)
def cqrscore(y,q):return np.maximum(np.maximum(q[...,0]-y,y-q[...,2]),0)
def qtile(a,level=.9):
 if len(a)==0:return 0.
 return float(np.quantile(a,min(1,np.ceil((len(a)+1)*level)/len(a)),method='higher'))
def mixquant(s,a,g,age,reg,tau):
 leaf=(a==age)&(g==reg);parent=(a==age);n=leaf.sum();np_=parent.sum();wl=n/(n+tau) if n else 0.;wp=np_/(np_+tau) if np_ else 0.
 weights=np.full(len(s),(1-wl)*(1-wp)/len(s));
 if np_:weights[parent]+=(1-wl)*wp/np_
 if n:weights[leaf]+=wl/n
 order=np.argsort(s);ss=s[order];ww=weights[order];return float(ss[min(np.searchsorted(np.cumsum(ww),.9),len(ss)-1)])

def calibrate(q,initmask,targetmask,method,tau=128,window=14):
 out=q.copy();left=np.maximum(q[:,:,:,1]-q[:,:,:,0],13.);right=np.maximum(q[:,:,:,2]-q[:,:,:,1],13.);s=np.maximum((q[:,:,:,1]-left-Y[:,None,:])/left,(Y[:,None,:]-q[:,:,:,1]-right)/right)
 targetdays=sorted(days[targetmask].unique());history=initmask.copy();alpha=np.full((3,4),.1)
 for day in targetdays:
  ii=np.where(targetmask&(days==day))[0];pool=np.where(history&(days<day)&(days>=day-pd.Timedelta(days=window)))[0]
  if method=='Fixed':pool=np.where(initmask)[0]
  assert len(pool)>0 and (tm[pool]+pd.Timedelta(minutes=60)<day).all()
  for h in range(4):
   scores=s[pool,:,h].ravel();aa=np.tile(np.arange(3),len(pool));gg=np.repeat(group[pool],3)
   for a in range(3):
    if method in ['Fixed','Rolling','ACI']:v=qtile(scores,1-alpha[a,h] if method=='ACI' else .9);corr=np.full(len(ii),v)
    else:
     corr=np.empty(len(ii))
     for g in [0,1]:
      vals=s[pool[group[pool]==g],a,h]
      val=qtile(vals) if method=='Separate' and len(vals)>0 else (mixquant(scores,aa,np.zeros_like(gg),a,0,tau) if method=='AgeOnly' else mixquant(scores,np.zeros_like(aa),gg,0,g,tau) if method=='RampOnly' else mixquant(scores,aa,gg,a,g,tau))
      corr[group[ii]==g]=val
    out[ii,a,h,0]=q[ii,a,h,1]-(1+corr)*left[ii,a,h];out[ii,a,h,2]=q[ii,a,h,1]+(1+corr)*right[ii,a,h]
    if method=='ACI':
     err=np.mean((Y[ii,h]<out[ii,a,h,0])|(Y[ii,h]>out[ii,a,h,2]));alpha[a,h]=np.clip(alpha[a,h]+.03*(.1-err),.01,.4)
  if method!='Fixed':history[ii]=True
 return out

rows=[];pointrows=[];selected={}
def metrics(name,q,mask,kind='test'):
 for a,age in enumerate(ages):
  for h,hor in enumerate(H):
   for label,gmask in [('All',np.ones(len(Y),bool)),('Ramp',group==1),('Stable',group==0),('Daylight',z['targetirr'][:,h]>20)]:
    sel=mask&gmask;y=Y[sel,h];qq=q[sel,a,h];lo,med,hi=qq.T
    rows.append({'model':name,'partition':kind,'age':age,'horizon':hor,'subset':label,'n':len(y),'MAE':np.mean(abs(y-med)),'RMSE':np.sqrt(np.mean((y-med)**2)),'coverage':np.mean((y>=lo)&(y<=hi)),'width':np.mean(hi-lo),'IS90':np.mean(intervalscore(y,lo,hi)),'pinball':np.maximum(np.array([.05,.5,.95])*(y[:,None]-qq),(np.array([.05,.5,.95])-1)*(y[:,None]-qq)).mean()})

if __name__=='__main__':
 test=split==3;cal=split==2;val=split==1
 # Single seeded primary forecaster; additional seeds measure training variation.
 neural=np.load(R/'TCN-17.npz')['q'];trees=np.load(R/'Quantile-boosting.npz')['q']
 # Tuning uses July only; first seven days supply the initial residual pool.
 warm=val&(days<pd.Timestamp('2021-07-08'));vtest=val&~warm
 tuning=[]
 for tau in [32,128,512]:
  qq=calibrate(trees,warm,vtest,'Pooled',tau);score=intervalscore(Y[vtest,None,:],qq[vtest,:,:,0],qq[vtest,:,:,2]).mean();tuning.append({'tau':tau,'IS90':float(score)})
 tau=min(tuning,key=lambda a:a['IS90'])['tau'];selected={'primary model':'Quantile boosting (July pinball selection)','tau':tau,'tuning':tuning,'window days':14,'ACI daily step':.03};print(selected,flush=True)
 allq={}
 for name,base in [('TCN',neural),('Boosting',trees)]:
  allq[name+' raw']=base;metrics(name+' raw',base,test)
  for method in ['Fixed','Rolling','ACI','Separate','AgeOnly','RampOnly','Pooled']:
   qq=calibrate(base,cal,test,method,tau);label=name+' '+method;allq[label]=qq;metrics(label,qq,test)
 for f in ['TCN-29','TCN-43','GRU-17','MLP-17','TCN-17-anchor1-age0-augment1','TCN-17-anchor0-age1-augment1','TCN-17-anchor1-age1-augment0']:
  qq=np.load(R/(f+'.npz'))['q'];allq[f]=qq;metrics(f,qq,test)
  qq=calibrate(qq,cal,test,'Pooled',tau);allq[f+' Pooled']=qq;metrics(f+' Pooled',qq,test)
 point={'Persistence':np.broadcast_to(X if False else z['X'][:,0,-1,0,None,None]*SCALE,(len(Y),3,4)).copy(),'Ridge':np.load(R/'Ridge.npz')['point']}
 for name,pred in point.items():
  for a,age in enumerate(ages):
   for h,hor in enumerate(H):
    for label,sel in [('All',test),('Ramp',test&(group==1)),('Stable',test&(group==0))]:
     e=Y[sel,h]-pred[sel,a,h];pointrows.append(dict(model=name,age=age,horizon=hor,subset=label,n=len(e),MAE=np.mean(abs(e)),RMSE=np.sqrt(np.mean(e**2))))
 pd.DataFrame(rows).to_csv(R/'metrics.csv',index=False);pd.DataFrame(pointrows).to_csv(R/'point-baselines.csv',index=False);(R/'calibration-settings.json').write_text(json.dumps(selected,indent=2))
 np.savez_compressed(R/'intervals.npz',**allq)
 # Paired daily bootstrap: mean interval score improvement over rolling calibration.
 daily=[]
 for a,age in enumerate(ages):
  for h,hor in enumerate(H):
   delta=intervalscore(Y[:,h],allq['Boosting Pooled'][:,a,h,0],allq['Boosting Pooled'][:,a,h,2])-intervalscore(Y[:,h],allq['Boosting Rolling'][:,a,h,0],allq['Boosting Rolling'][:,a,h,2])
   for day in sorted(days[test].unique()):daily.append(dict(date=str(day.date()),age=age,horizon=hor,difference=float(delta[test&(days==day)].mean())))
 df=pd.DataFrame(daily);df.to_csv(R/'daily-differences.csv',index=False);rng=np.random.default_rng(2026);boots=[]
 for (a,h),dd in df.groupby(['age','horizon']):
  ar=dd.difference.to_numpy();starts=rng.integers(0,len(ar),(2000,int(np.ceil(len(ar)/7))));indices=(starts[:,:,None]+np.arange(7)[None,None,:])%len(ar);samp=ar[indices.reshape(2000,-1)[:,:len(ar)]].mean(1);boots.append(dict(age=int(a),horizon=int(h),difference=float(ar.mean()),low=float(np.quantile(samp,.025)),high=float(np.quantile(samp,.975))))
 pd.DataFrame(boots).to_csv(R/'bootstrap.csv',index=False)
 print(pd.DataFrame(rows).query("subset=='All' and age==0 and horizon==30")[['model','MAE','coverage','width','IS90']].to_string(index=False),flush=True)
