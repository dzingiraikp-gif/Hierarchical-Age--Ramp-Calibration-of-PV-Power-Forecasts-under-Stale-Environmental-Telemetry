"""Inspect the included public one-day data sample without training a model."""
import hashlib,json,pathlib
import pandas as pd
P=pathlib.Path(__file__).resolve().parents[1]
def main():
 f=P/'data/sample.csv';meta=json.loads((P/'data/source.json').read_text());digest=hashlib.sha256(f.read_bytes()).hexdigest()
 if digest!=meta['sample_sha256']:raise ValueError('Sample checksum does not match source.json')
 d=pd.read_csv(f);t=pd.to_datetime(d.measured_on)
 if t.duplicated().any() or not t.is_monotonic_increasing:raise ValueError('Unexpected timestamp structure')
 print(json.dumps({'records':len(d),'first':str(t.min()),'last':str(t.max()),'system_ids':d.system_id.unique().tolist(),'measurement_columns':list(d.columns[1:-1]),'empty_cells':int(d.isna().sum().sum()),'checksum_matches':True},indent=2))
if __name__=='__main__':main()
