"""Reproduce forecasts from the original CSV directory. Python 3.12, CPU only."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2');os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import argparse, pathlib, json,time,copy,hashlib
import numpy as np,pandas as pd
import joblib
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
import torch
from torch import nn
from torch.utils.data import DataLoader,TensorDataset
P=pathlib.Path(__file__).resolve().parents[1];R=P/'results';R.mkdir(exist_ok=True)
torch.set_num_threads(2)
H=np.array([5,15,30,60]);AGES=[0,15,60];QS=np.array([.05,.5,.95]);SCALE=1300.

def prepare(root,external=False):
 fs=sorted(pathlib.Path(root).rglob('*.csv'));d=pd.concat([pd.read_csv(f) for f in fs],ignore_index=True)
 d['measured_on']=pd.to_datetime(d.measured_on);d=d.sort_values('measured_on').set_index('measured_on')
 assert not d.index.duplicated().any()
 report={'files':len(fs),'records':len(d),'columns':list(d.columns),'empty cells':int(d.isna().sum().sum()),'first':str(d.index.min()),'last':str(d.index.max()),'systems':d.system_id.unique().tolist()}
 full=pd.date_range(d.index.min(),d.index.max(),freq='min');d=d.reindex(full)
 v=pd.DataFrame(index=full)
 for n,c in [('power','ac_power__423'),('irradiance','poa_irradiance__421'),('ambient','ambient_temp__428'),('inverter','inverter_temp__432'),('dc','dc_power__422')]:v[n]=d[c]
 mt=d[['module_temp_1__429','module_temp_2__430','module_temp_3__431']];v['module']=mt.mean(axis=1);v['spread']=mt.max(axis=1)-mt.min(axis=1)
 # No filling: all required past samples and four future targets must be observed.
 a=v.to_numpy(np.float32);pos=np.arange(60,len(a)-60,5);clock=full[pos]
 good=(clock.hour>=6)&(clock.hour<18)
 hist=pos[:,None]+np.arange(-60,1,5)[None,:];yp=pos[:,None]+H[None,:]
 good&=np.isfinite(a[hist]).all(axis=(1,2))&np.isfinite(a[yp,0]).all(axis=1)
 # Exclude any recording break between first historical minute and last target minute.
 observed=d.system_id.notna().to_numpy();missing=(~observed).astype(int).cumsum();good&=(missing[pos+60]-missing[pos-60])==0
 pos=pos[good];hist=hist[good];yp=yp[good];clock=full[pos]
 X=[]
 for age in AGES:
  z=a[hist].copy();end=pos-age
  # Environmental telemetry is frozen after t-age. Electrical channels remain observed.
  for j in [1,2,3,5,6]:z[:,:,j]=a[np.minimum(hist,end[:,None]),j]
  agepath=np.maximum(hist-end[:,None],0)/60
  z=np.concatenate([z,agepath[:,:,None]],axis=2)
  X.append(z)
 X=np.stack(X,axis=1)
 # Fixed, declared numerical scales, not estimates of rated capacity.
 div=np.array([SCALE,1500,50,70,SCALE,70,15,1],np.float32);X/=div
 Y=a[yp,0]/SCALE
 cyc=np.stack([np.sin(2*np.pi*(clock.hour+clock.minute/60)/24),np.cos(2*np.pi*(clock.hour+clock.minute/60)/24),np.sin(2*np.pi*clock.dayofyear/365),np.cos(2*np.pi*clock.dayofyear/365)],1).astype('float32')
 X=np.concatenate([X,np.broadcast_to(cyc[:,None,None,:],(*X.shape[:3],4))],axis=3).astype('float32')
 # Split based on issuance and latest target, eliminating target crossover.
 split=np.full(len(pos),-1);ends=pd.to_datetime(clock)+pd.to_timedelta(60,unit='min')
 for k,(start,end) in enumerate([('2021-01-01','2021-07-01'),('2021-07-01','2021-08-01'),('2021-08-01','2021-09-01'),('2021-09-01','2022-01-01')]):split[(clock>=start)&(ends<pd.Timestamp(end))]=k
 if external:split[:]=3
 assert (split>=0).all()
 ramp=np.abs(a[pos,0]-a[pos-15,0])/SCALE;threshold=(json.loads((P/'results'/'data-summary.json').read_text())['ramp threshold native']/SCALE if external else float(np.quantile(ramp[split==0],.8)));group=(ramp>threshold).astype(int)
 report.update({'samples':len(pos),'split counts':{str(i):int((split==i).sum()) for i in range(4)},'ramp threshold native':threshold*SCALE,'scale':SCALE,'feature order':['power','irradiance','ambient','inverter','dc','module','spread','age','hour sin','hour cos','year sin','year cos'],'missing days':[str(t.date()) for t in pd.date_range(full[0].normalize(),full[-1].normalize()).difference(d.index[d.system_id.notna()].normalize().unique())]})
 (R/'data-summary.json').write_text(json.dumps(report,indent=2));pd.DataFrame({'file':[str(f.relative_to(root)) for f in fs],'sha256':[hashlib.sha256(f.read_bytes()).hexdigest() for f in fs]}).to_csv(R/'input-hashes.csv',index=False)
 np.savez_compressed(R/'prepared.npz',X=X,Y=Y,split=split,time=clock.asi8,group=group,ramp=ramp,targetirr=a[yp,1])
 print(report,flush=True)
 return X,Y,split,clock.asi8,group

class Forecast(nn.Module):
 def __init__(self,kind='TCN',anchor=True):
  super().__init__();self.kind=kind;self.anchor=anchor
  if kind=='TCN':
   self.convs=nn.ModuleList([nn.Conv1d(12 if i==0 else 24,24,3,dilation=2**i) for i in range(3)])
   self.head=nn.Linear(24,12)
  elif kind=='MLP':self.mlp=nn.Sequential(nn.Flatten(),nn.Linear(156,64),nn.ReLU(),nn.Linear(64,24),nn.ReLU());self.head=nn.Linear(24,12)
  else:self.rnn=nn.GRU(12,24,batch_first=True);self.head=nn.Linear(24,12)
 def forward(self,x):
  if self.kind=='TCN':
   z=x.transpose(1,2)
   for i,c in enumerate(self.convs):z=torch.relu(c(nn.functional.pad(z,(2*(2**i),0))))
   z=z[:,:,-1]
  elif self.kind=='MLP':z=self.mlp(x)
  else:z=self.rnn(x)[0][:,-1]
  q=self.head(z).reshape(-1,4,3)
  median=q[:,:,1]+(x[:,-1,0,None] if self.anchor else 0)
  return torch.stack([median-nn.functional.softplus(q[:,:,0]),median,median+nn.functional.softplus(q[:,:,2])],-1)

def trainnet(X,Y,split,kind,seed,anchor=True,ageaware=True,augment=True):
 torch.manual_seed(seed);np.random.seed(seed);m=Forecast(kind,anchor);opt=torch.optim.Adam(m.parameters(),lr=.002)
 ids=np.where(split==0)[0];val=np.where(split==1)[0];rng=np.random.default_rng(seed)
 best=1e9;beststate=None;hist=[];start=time.perf_counter()
 for epoch in range(16):
  ages=rng.integers(0,3,len(ids)) if augment else np.zeros(len(ids),int)
  xx=X[ids,ages].copy()
  if not ageaware:xx[:,:,7]=0
  ds=DataLoader(TensorDataset(torch.tensor(xx),torch.tensor(Y[ids])),batch_size=512,shuffle=True)
  m.train()
  for x,y in ds:
   opt.zero_grad();q=m(x);e=y[:,:,None]-q;loss=torch.maximum(torch.tensor(QS,dtype=torch.float32)*e,(torch.tensor(QS,dtype=torch.float32)-1)*e).mean();loss.backward();opt.step()
  m.eval()
  with torch.no_grad():
   vv=X[val].reshape(-1,13,12).copy()
   if not ageaware:vv[:,:,7]=0
   pred=m(torch.tensor(vv)).numpy().reshape(len(val),3,4,3);err=Y[val,None,:,None]-pred;vl=float(np.maximum(QS*err,(QS-1)*err).mean())
  hist.append(vl)
  if vl<best:best=vl;beststate=copy.deepcopy(m.state_dict())
 m.load_state_dict(beststate);m.eval();out=[]
 with torch.no_grad():
  for z in np.array_split(X.reshape(-1,13,12),max(1,len(X)*3//4096)):
   z=z.copy()
   if not ageaware:z[:,:,7]=0
   out.append(m(torch.tensor(z)).numpy())
 pred=np.concatenate(out).reshape(len(X),3,4,3)*SCALE
 label=f'{kind}-{seed}'+('' if anchor and ageaware and augment else f'-anchor{int(anchor)}-age{int(ageaware)}-augment{int(augment)}')
 np.savez_compressed(R/(label+'.npz'),q=pred,history=hist,seconds=time.perf_counter()-start,parameters=sum(p.numel() for p in m.parameters()))
 torch.save(m.state_dict(),R/(label+'.pt'));print(label,'val',best,'seconds',time.perf_counter()-start,flush=True)
 return pred

def trees(X,Y,split):
 ids=np.where(split==0)[0];rng=np.random.default_rng(17);age=rng.integers(0,3,len(ids));xx=X[ids,age].reshape(len(ids),-1)
 vv=X[split==1].reshape(-1,156);yy=np.repeat(Y[split==1],3,axis=0)
 # Chronological validation chooses one shared depth budget; no test outcomes are used.
 candidates=[7,15];scores=[]
 for leaves in candidates:
  m=HistGradientBoostingRegressor(max_iter=100,max_leaf_nodes=leaves,learning_rate=.08,l2_regularization=2,early_stopping=False,random_state=17).fit(xx,Y[ids,2]);scores.append(np.mean(np.abs(m.predict(vv)-yy[:,2])))
 leaves=candidates[int(np.argmin(scores))];q=np.empty((len(X),3,4,3));start=time.perf_counter()
 for h in range(4):
  for j,quant in enumerate(QS):
   m=HistGradientBoostingRegressor(loss='quantile',quantile=quant,max_iter=100,max_leaf_nodes=leaves,learning_rate=.08,l2_regularization=2,early_stopping=False,random_state=17).fit(xx,Y[ids,h]);q[:,:,h,j]=m.predict(X.reshape(-1,156)).reshape(len(X),3)*SCALE;joblib.dump(m,R/f'boosting-h{h}-q{j}.joblib')
 q.sort(axis=-1);np.savez_compressed(R/'Quantile-boosting.npz',q=q,seconds=time.perf_counter()-start,leaves=leaves,validation=scores)
 print('trees',leaves,'seconds',time.perf_counter()-start,flush=True)
 # Standardized linear multi-output baseline with a validation-selected penalty.
 sc=StandardScaler().fit(xx);zz=sc.transform(xx);best=None
 for alpha in [1,100,10000]:
  m=Ridge(alpha=alpha).fit(zz,Y[ids]);loss=np.mean(np.abs(m.predict(sc.transform(vv))-yy))
  if best is None or loss<best[0]:best=(loss,m)
 out=best[1].predict(sc.transform(X.reshape(-1,156))).reshape(len(X),3,4)*SCALE;np.savez_compressed(R/'Ridge.npz',point=out)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--data');ap.add_argument('--prepare',action='store_true');ap.add_argument('--models',default='all');args=ap.parse_args()
 if args.prepare: X,Y,split,t,g=prepare(args.data)
 else:
  z=np.load(R/'prepared.npz');X,Y,split,t,g=[z[n] for n in ['X','Y','split','time','group']]
 if args.models in ['all','neural']:
  for seed in [17,29,43]:trainnet(X,Y,split,'TCN',seed)
  trainnet(X,Y,split,'GRU',17)
  trainnet(X,Y,split,'MLP',17)
  trainnet(X,Y,split,'TCN',17,ageaware=False)
  trainnet(X,Y,split,'TCN',17,anchor=False)
  trainnet(X,Y,split,'TCN',17,augment=False)
 if args.models in ['all','trees']:trees(X,Y,split)
