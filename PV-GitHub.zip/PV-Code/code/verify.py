"""Scientific consistency checks for completed experiment outputs."""
import pathlib,json
import numpy as np,pandas as pd,joblib
P=pathlib.Path(__file__).resolve().parents[1];R=P/'results'
z=np.load(R/'prepared.npz');t=pd.to_datetime(z['time']);X=z['X'];y=z['Y']*1300
assert np.isfinite(X).all() and np.isfinite(y).all()
assert X.shape==(52065,3,13,12)
assert (np.diff(t.asi8)>0).all()
for a in range(3):
 assert np.array_equal(X[:,0,:,0],X[:,a,:,0])
 assert np.array_equal(X[:,0,:,4],X[:,a,:,4])
assert (X[:,0,:,7]==0).all()
assert np.allclose(X[:,2,:,1],X[:,2,:1,1])
for k,end in enumerate(['2021-07-01','2021-08-01','2021-09-01','2022-01-01']):assert (t[z['split']==k]+pd.Timedelta(minutes=60)<pd.Timestamp(end)).all()
q=np.load(R/'intervals.npz');n=0
for name in q.files:
 a=q[name];assert a.shape==(len(t),3,4,3);assert np.isfinite(a).all();assert (np.diff(a,axis=-1)>=-1e-5).all(),name;n+=1
base=np.load(R/'Quantile-boosting.npz')['q'];ids=np.array([0,100,10000,30000,52000]);replay=np.empty((len(ids),3,4,3))
for h in range(4):
 for j in range(3):replay[:,:,h,j]=joblib.load(R/f'boosting-h{h}-q{j}.joblib').predict(X[ids].reshape(-1,156)).reshape(len(ids),3)*1300
replay.sort(axis=-1);assert np.allclose(replay,base[ids])
m=pd.read_csv(R/'metrics.csv');sel=z['split']==3;a=q['Boosting Pooled'][sel,0,2];cov=np.mean((y[sel,2]>=a[:,0])&(y[sel,2]<=a[:,2]));r=m.query('model=="Boosting Pooled" and subset=="All" and age==0 and horizon==30').iloc[0];assert abs(cov-r.coverage)<1e-12
result={'finite input windows':True,'chronological target partitions':True,'electrical channels retained in age scenarios':True,'ordered interval arrays':n,'saved boosting replay':True,'reported coverage replay':True}
(R/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
