"""Download the exact 2021 source days or the frozen January 2022 extension."""
import argparse,concurrent.futures,hashlib,json,pathlib,re,urllib.request
P=pathlib.Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--year',type=int,choices=[2021,2022],required=True);ap.add_argument('--destination',required=True);args=ap.parse_args();dest=pathlib.Path(args.destination);dest.mkdir(parents=True,exist_ok=True)
 if args.year==2021:
  import csv
  with open(P/'results'/'input-hashes.csv') as f:rows=list(csv.DictReader(f))
  todo=[]
  for r in rows:
   yy,mm,dd=re.search(r'date_(\d{4})_(\d{2})_(\d{2})',r['file']).groups();todo.append((int(yy),int(mm),int(dd),r['sha256']))
 else:todo=[(2022,1,d,None) for d in range(1,31)]
 def get(row):
  year,month,day,expected=row;u=f'https://oedi-data-lake.s3.amazonaws.com/pvdaq/csv/pvdata/system_id=10/year={year}/month={month}/day={day}/system_10__date_{year}_{month:02d}_{day:02d}.csv'
  data=urllib.request.urlopen(u,timeout=60).read();digest=hashlib.sha256(data).hexdigest()
  if expected and digest!=expected:raise RuntimeError(f'Source version changed for {year}-{month:02d}-{day:02d}. Use the supplied original archive to reproduce this version.')
  f=dest/f'{year}-{month:02d}-{day:02d}.csv';f.write_bytes(data);return {'file':f.name,'url':u,'sha256':digest,'bytes':len(data)}
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:manifest=list(ex.map(get,todo))
 (dest/'download-records.json').write_text(json.dumps(manifest,indent=2));print('Downloaded',len(manifest),'day files')
if __name__=='__main__':main()
