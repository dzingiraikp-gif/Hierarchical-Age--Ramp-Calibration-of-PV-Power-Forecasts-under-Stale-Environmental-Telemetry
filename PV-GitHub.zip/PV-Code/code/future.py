"""Frozen-model January 2022 experiment. Downloads are performed separately."""
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
import pathlib,importlib,sys,json
import numpy as np,pandas as pd,joblib
import experiment as e
from evaluate import intervalscore
P=e.P;R=e.R;root=sys.argv[1];er=R/'future';er.mkdir(exist_ok=True);e.R=er
X,Y,split,t,g=e.prepare(root,external=True);e.R=R
q=np.empty((len(X),3,4,3))
for h in range(4):
 for j in range(3):q[:,:,h,j]=joblib.load(R/f'boosting-h{h}-q{j}.joblib').predict(X.reshape(-1,156)).reshape(len(X),3)*1300
q.sort(axis=-1)
import evaluate as ev
z=np.load(R/'prepared.npz');mainq=np.load(R/'Quantile-boosting.npz')['q'];oldtime=pd.to_datetime(z['time']);init=oldtime>=pd.Timestamp('2021-12-18')
# Only late December initializes the completely separate future-year experiment.
ev.Y=np.concatenate([z['Y'][init],Y])*1300;ev.tm=pd.to_datetime(np.concatenate([z['time'][init],t]));ev.days=ev.tm.normalize();ev.group=np.concatenate([z['group'][init],g]);qq=np.concatenate([mainq[init],q]);n=init.sum();im=np.arange(len(qq))<n;test=~im;tau=json.loads((R/'calibration-settings.json').read_text())['tau'];records=[];outputs={}
for method in ['raw','Fixed','Rolling','ACI','Separate','Pooled']:
 out=qq if method=='raw' else ev.calibrate(qq,im,test,method,tau)
 outputs[method]=out[test].astype('float32')
 for a,age in enumerate([0,15,60]):
  for h,hor in enumerate([5,15,30,60]):
   for subset,gs in [('All',np.ones(len(Y),bool)),('Ramp',g==1),('Stable',g==0)]:
    y=Y[gs,h]*1300;pred=out[test][gs,a,h];lo,med,hi=pred.T
    records.append(dict(model=method,age=age,horizon=hor,subset=subset,n=len(y),MAE=float(np.mean(abs(y-med))),coverage=float(np.mean((y>=lo)&(y<=hi))),width=float(np.mean(hi-lo)),IS90=float(ev.intervalscore(y,lo,hi).mean())))
 np.savez_compressed(er/'intervals.npz',**outputs)
pd.DataFrame(records).to_csv(R/'future-metrics.csv',index=False);np.savez_compressed(er/'targets.npz',Y=Y*1300,time=t,group=g)
print(pd.DataFrame(records).query("subset=='All'").groupby('model')[['MAE','coverage','width','IS90']].mean().to_string())
