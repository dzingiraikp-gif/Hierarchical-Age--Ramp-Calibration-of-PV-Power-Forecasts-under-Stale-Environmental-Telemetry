"""Numerical checks of the analytical identities and data-table reconciliation."""
import pathlib,json
import numpy as np,pandas as pd
P=pathlib.Path(__file__).resolve().parents[1];rng=np.random.default_rng(2026)
for _ in range(200):
 m=rng.normal();dm,dp=rng.uniform(.1,5,2);y=rng.normal(size=100);c=rng.uniform(-.99,4)
 s=np.maximum((m-dm-y)/dm,(y-m-dp)/dp)
 piece=np.where(y<=m,(m-y)/dm-1,(y-m)/dp-1)
 assert np.allclose(s,piece)
 assert np.array_equal(s<=c,(y>=m-(1+c)*dm)&(y<=m+(1+c)*dp))
 n,tau=rng.uniform(1,1000,2);f,g=rng.uniform(size=2);sol=(n*f+tau*g)/(n+tau)
 assert abs(n*(sol-f)+tau*(sol-g))<1e-9
 for other in [0,1,rng.uniform()]:assert n*(sol-f)**2+tau*(sol-g)**2 <= n*(other-f)**2+tau*(other-g)**2+1e-10
 wr,wa=rng.uniform(size=2);weights=np.array([wr,(1-wr)*wa,(1-wr)*(1-wa)]);assert abs(weights.sum()-1)<1e-14
 scores=np.sort(rng.normal(size=20));sw=rng.dirichlet(np.ones(20));cum=sw.cumsum();i=np.searchsorted(cum,.9);assert .9<=cum[i]<=.9+sw.max()+1e-12
monthly=pd.read_csv(P/'results/monthly-inventory.csv');stats=pd.read_csv(P/'results/measurement-statistics.csv')
assert monthly.records.sum()==521150
assert monthly.missing_records.sum()==4450
assert monthly.empty_cells.sum()==stats.missing.sum()==28
assert len(pd.read_csv(P/'results/sample-observations.csv'))==6
r={'score inversion':True,'piecewise asymmetric score':True,'CDF quadratic minimizer':True,'mixture weights':True,'empirical quantile jump bound':True,'monthly record total':521150,'absent minutes':4450,'empty sensor cells':28,'source sample rows':6}
(P/'results/mathematical-checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
